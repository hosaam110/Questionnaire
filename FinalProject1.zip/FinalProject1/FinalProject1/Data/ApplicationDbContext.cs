﻿using FinalProject1.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalProject1.Data
{
    //This class represents the database context for the application. 
    public class ApplicationDbContext : DbContext
    {
        //allowing the application to provide the necessary options for configuring the database context.
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        //It allows you to perform database operations such as querying, inserting, updating, and deleting 
        public DbSet<UserDetails> UserDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            // Reset the identity column on UserDetails table
            modelBuilder.Entity<UserDetails>()
        .Property(u => u.Id)
        .UseIdentityColumn(1, 1); // Start from 1 and increment by 1
        }
    }
}
