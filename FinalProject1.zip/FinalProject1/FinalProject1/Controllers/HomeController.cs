﻿using FinalProject1.Data;
using FinalProject1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

/*The main controller class that inherits from the Controller class provided*/
public class HomeController : Controller
{
    [HttpGet]
    [Route("Home/ThankYou")]
    public IActionResult ThankYou()
    {
        return View();
    }

    public IActionResult About()
    {
        // Add your logic here
        return View();
    }

    private readonly ApplicationDbContext _dbContext;

    public HomeController(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }
    //GET request for the default home page.
    public IActionResult Index()
    {
        return View();
    }
    // ErrorViewModel to hold error information
    public class ErrorViewModel
    {
        //Includes properties like 
        public string RequestId { get; set; }
        public bool ShowRequestId { get; set; }
    }


    [HttpPost]
    [ValidateAntiForgeryToken]
    //handles the POST request when a user submits a questionnaire.
    public IActionResult SubmitQuestionnaire(QuestionnaireViewModel model)
    {
        if (ModelState.IsValid)
        {
            try
            {
                // Save the questionnaire data to the database
                var userDetails = new UserDetails
                {
                    Name = model.Name,
                    Feedback = model.Feedback,
                    SatisfactionLevel = model.SatisfactionLevel
                };
                //saves the changes to the database using
                _dbContext.UserDetails.Add(userDetails);
                _dbContext.SaveChanges();

                return RedirectToAction("ThankYou");
            }
            catch (Exception ex)
            {
                // Log or handle the exception as needed
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.StackTrace);

                // Optionally, you can show an error view to the user
                return View("Error");
            }
        }

        // If the form is not valid, return the same view with validation errors
        return View("Index", model);
    }

    [HttpGet]
    public IActionResult UserDetails()
    {
        // Retrieve all user details from the database

        var userDetails = _dbContext.UserDetails.ToList();

        var viewModel = new UserDetailsViewModel
        {
            UserList = userDetails
        };

        return View(viewModel);
    }


    [HttpPost]
    [Route("Home/DeleteUserDetail")]
    //POST request to delete a user detail from the database.
    public IActionResult DeleteUserDetail(int id)
    {
        var userDetail = _dbContext.UserDetails.Find(id);
        if (userDetail != null)
        {
            //saves the changes to the database.
            _dbContext.UserDetails.Remove(userDetail);
            _dbContext.SaveChanges();
        }

        return RedirectToAction("UserDetails");
    }

    
}
