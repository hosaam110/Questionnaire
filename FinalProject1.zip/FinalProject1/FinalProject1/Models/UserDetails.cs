﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinalProject1.Models
{
    [Table("UserDetails")] // Specify the table name
    public class UserDetails
    {
        [Key]
        [Required]
        [Column("Id")]
        public int Id { get; set; }

        [Required]
        [Column("Name")] // Specify the column name
        public string Name { get; set; }

        [Required]
        [Column("FeedBack")] // Specify the column name
        public string Feedback { get; set; }

        [Required]
        [Range(1, 4)]
        [Column("Satisfied")] // Specify the column name
        public int SatisfactionLevel { get; set; }
    }

    //view model for displaying a list of user details 
    public class UserDetailsViewModel
    {
        public List<UserDetails> UserList { get; set; }
    }


}