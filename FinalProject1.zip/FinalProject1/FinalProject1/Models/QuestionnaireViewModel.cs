﻿using System.ComponentModel.DataAnnotations;


namespace FinalProject1.Models
{

    //It holds properties that capture information
    public class QuestionnaireViewModel
    {
        [Required]
        public string? Name { get; set; }

        [Required]
        public string? Feedback { get; set; }

        [Required]
        [Range(1, 4)]
        public int SatisfactionLevel { get; set; }
    }
}
